package cl.duoc.miprimeraapi.model.repository;

import cl.duoc.miprimeraapi.model.ValorDolar;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ValorDolarRepository extends JpaRepository<ValorDolar, Long> {
    ValorDolar findTopByOrderByFechaDesc();
}
