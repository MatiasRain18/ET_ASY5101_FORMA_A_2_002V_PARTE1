package cl.duoc.miprimeraapi.model.repository;

import cl.duoc.miprimeraapi.model.TransaccionPago;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TransaccionPagoRepository extends JpaRepository<TransaccionPago, Long> {
    List<TransaccionPago> findByCodigoProducto(String codigoProducto);
}
