package cl.duoc.miprimeraapi.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

@Entity
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El código del producto es obligatorio")
    @Column(unique = true)
    private String codigoProducto;

    @NotBlank(message = "La marca del producto es obligatoria")
    private String marca;

    @NotBlank(message = "El nombre del producto es obligatorio")
    private String nombre;

    @NotNull(message = "El precio es obligatorio")
    @Positive(message = "El precio debe ser mayor que 0")
    private Double precio;

    @NotNull(message = "El stock es obligatorio")
    @PositiveOrZero(message = "El stock no puede ser negativo")
    private Integer stock;

    @NotBlank(message = "La categoría del producto es obligatoria")
    private String categoria;

    private LocalDateTime fechaPrecio;

    // Getters y Setters

    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public String getCodigoProducto() { return codigoProducto; }

    public void setCodigoProducto(String codigoProducto) { this.codigoProducto = codigoProducto; }

    public String getMarca() { return marca; }

    public void setMarca(String marca) { this.marca = marca; }

    public String getNombre() { return nombre; }

    public void setNombre(String nombre) { this.nombre = nombre; }

    public Double getPrecio() { return precio; }

    public void setPrecio(Double precio) { this.precio = precio; }

    public Integer getStock() { return stock; }

    public void setStock(Integer stock) { this.stock = stock; }

    public String getCategoria() { return categoria; }

    public void setCategoria(String categoria) { this.categoria = categoria; }

    public LocalDateTime getFechaPrecio() { return fechaPrecio; }

    public void setFechaPrecio(LocalDateTime fechaPrecio) { this.fechaPrecio = fechaPrecio; }
}
