package cl.duoc.miprimeraapi.controller;

import cl.duoc.miprimeraapi.model.Producto;
import cl.duoc.miprimeraapi.model.repository.ProductoRepository;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/productos")
public class ProductoController {

    @Autowired
    private ProductoRepository productoRepository;

    @Operation(summary = "Crear un nuevo producto")
    @PostMapping
    public ResponseEntity<?> crearProducto(@RequestBody Producto producto) {

        // Validación: código de producto duplicado
        Producto existente = productoRepository.findByCodigoProducto(producto.getCodigoProducto());
        if (existente != null) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("⚠️ El producto con código " + producto.getCodigoProducto() + " ya está registrado.");
        }

        // Validación: código obligatorio
        if (producto.getCodigoProducto() == null || producto.getCodigoProducto().isBlank()) {
            return ResponseEntity.badRequest()
                    .body("⚠️ El código del producto es obligatorio.");
        }

        // Validación: nombre obligatorio
        if (producto.getNombre() == null || producto.getNombre().isBlank()) {
            return ResponseEntity.badRequest()
                    .body("⚠️ El nombre del producto es obligatorio.");
        }

        // Validación: marca obligatoria
        if (producto.getMarca() == null || producto.getMarca().isBlank()) {
            return ResponseEntity.badRequest()
                    .body("⚠️ La marca del producto es obligatoria.");
        }

        // Validación: categoría obligatoria
        if (producto.getCategoria() == null || producto.getCategoria().isBlank()) {
            return ResponseEntity.badRequest()
                    .body("⚠️ La categoría del producto es obligatoria.");
        }

        // Validación: precio positivo
        if (producto.getPrecio() == null || producto.getPrecio() <= 0) {
            return ResponseEntity.badRequest()
                    .body("⚠️ El precio debe ser un valor positivo.");
        }

        // Validación: stock no negativo
        if (producto.getStock() == null || producto.getStock() < 0) {
            return ResponseEntity.badRequest()
                    .body("⚠️ El stock no puede ser negativo.");
        }

        // Si todas las validaciones pasan, se guarda el producto
        return ResponseEntity.status(HttpStatus.CREATED).body(productoRepository.save(producto));
    }

    @Operation(summary = "Buscar producto por código")
    @GetMapping("/{codigo}")
    public Producto obtenerPorCodigo(@PathVariable String codigo) {
        return productoRepository.findByCodigoProducto(codigo);
    }

    @Operation(summary = "Buscar productos por nombre (contiene)")
    @GetMapping("/buscarNombre")
    public List<Producto> buscarPorNombre(@RequestParam String nombre) {
        return productoRepository.findByNombreContainingIgnoreCase(nombre);
    }

    @Operation(summary = "Buscar productos por categoría")
    @GetMapping("/categoria")
    public List<Producto> buscarPorCategoria(@RequestParam String categoria) {
        return productoRepository.findByCategoria(categoria);
    }

    @Operation(summary = "Buscar productos con bajo stock")
    @GetMapping("/bajoStock")
    public List<Producto> productosBajoStock(@RequestParam Integer stock) {
        return productoRepository.findByStockLessThan(stock);
    }
}
