package cl.duoc.miprimeraapi.model.repository;

import cl.duoc.miprimeraapi.model.TransaccionDolar;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransaccionDolarRepository extends JpaRepository<TransaccionDolar, Long> {
}
