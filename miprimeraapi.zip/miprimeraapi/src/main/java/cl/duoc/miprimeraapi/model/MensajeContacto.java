package cl.duoc.miprimeraapi.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDateTime;

@Entity
public class MensajeContacto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "⚠️ El nombre no puede estar vacío.")
    private String nombre;

    @NotBlank(message = "⚠️ El email es obligatorio.")
    @Email(message = "⚠️ El formato del correo electrónico no es válido.")
    private String email;

    @NotBlank(message = "⚠️ El mensaje no puede estar vacío.")
    private String mensaje;

    private LocalDateTime fecha;

    public MensajeContacto() {
        this.fecha = LocalDateTime.now();
    }

    // Getters y Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }
}
