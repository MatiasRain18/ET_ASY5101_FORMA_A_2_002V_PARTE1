package cl.duoc.miprimeraapi.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class TransaccionDolar {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double valorDolar;
    private double montoEnDolares;
    private double montoEnPesos;
    private LocalDateTime fechaTransaccion;

    public Long getId() {
        return id;
    }

    public double getValorDolar() {
        return valorDolar;
    }

    public double getMontoEnDolares() {
        return montoEnDolares;
    }

    public double getMontoEnPesos() {
        return montoEnPesos;
    }

    public LocalDateTime getFechaTransaccion() {
        return fechaTransaccion;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setValorDolar(double valorDolar) {
        this.valorDolar = valorDolar;
    }

    public void setMontoEnDolares(double montoEnDolares) {
        this.montoEnDolares = montoEnDolares;
    }

    public void setMontoEnPesos(double montoEnPesos) {
        this.montoEnPesos = montoEnPesos;
    }

    public void setFechaTransaccion(LocalDateTime fechaTransaccion) {
        this.fechaTransaccion = fechaTransaccion;
    }
}
