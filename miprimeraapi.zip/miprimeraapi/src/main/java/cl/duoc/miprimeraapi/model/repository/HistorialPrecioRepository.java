package cl.duoc.miprimeraapi.model.repository;

import cl.duoc.miprimeraapi.model.HistorialPrecio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HistorialPrecioRepository extends JpaRepository<HistorialPrecio, Long> {
    List<HistorialPrecio> findByCodigoProducto(String codigoProducto);
}
