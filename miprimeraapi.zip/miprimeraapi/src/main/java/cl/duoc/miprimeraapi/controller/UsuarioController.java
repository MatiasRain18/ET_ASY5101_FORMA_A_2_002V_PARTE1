package cl.duoc.miprimeraapi.controller;

import cl.duoc.miprimeraapi.model.Usuario;
import cl.duoc.miprimeraapi.model.repository.UsuarioRepository;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Operation(summary = "Obtener un usuario por ID")
    @GetMapping("/{id}")
    public Optional<Usuario> getUsuario(@PathVariable Long id) {
        return usuarioRepository.findById(id);
    }

    @Operation(summary = "Registrar un nuevo usuario (rol: interno o externo)")
    @PostMapping
    public ResponseEntity<?> postUsuario(@Valid @RequestBody Usuario usuario) {
        if (!usuario.getRol().equalsIgnoreCase("interno") && !usuario.getRol().equalsIgnoreCase("externo")) {
            return ResponseEntity.badRequest().body("⚠️ El rol debe ser 'interno' o 'externo'.");
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(usuarioRepository.save(usuario));
    }
}
